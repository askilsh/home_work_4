public class Body
{
	public static void main(String[] args)
	{
		Operation.met_calc();	
		//String str_in = "122.";		
	//	System.out.println(str_in.matches("\\d+||'.'"));
	}
	
}
